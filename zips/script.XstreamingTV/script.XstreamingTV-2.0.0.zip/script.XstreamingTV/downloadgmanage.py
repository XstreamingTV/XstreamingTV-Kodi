# -*- coding: utf-8 -*-
#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified for Mega Guide (09/2014 onwards)
#      by Thomas Geppert [bluezed] - bluezed.apps@gmail.com
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import xbmcgui
import xbmcaddon
import time, zipfile, urllib, urllib2, os, sys, json, requests
time = 2000 #in miliseconds

try:
  isactive = urllib2.urlopen("http://www.pythonwithphp.com/XstreamingTVUpdates/isactive.txt").read(20000)
except:
  isactive = ''

if isactive == 'No':
  xbmcgui.Dialog().ok('XstreamingTV', 'Access denied.', 'No active subscription found.', 'Visit xstreamingtv.com for subscription information.')
  os._exit(1)
elif isactive == 'Yes':
  print ''
else:
  xbmcgui.Dialog().ok('XstreamingTV', 'Unable to connect to server.', 'Visit xstreamingtv.com for support.')
  xbmc.executebuiltin('ActivateWindow(Home)')
  sys.exit(0)

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgressBG()
    if 'logosVader.zip' in url:
      dp.create("Guide","Downloading Channel Logos")
    else:
      dp.create("Guide","Downloading Guide Data")
    try:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
        percent = 100
        dp.update(percent)
        dp.close()
        donevalue = 'Done'
    except:
        donevalue = 'Failed'
        percent = 100
        dp.update(percent)
        dp.close()
    percent = 100
    dp.update(percent)
    dp.close()
    return donevalue
     
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
#    if dp.iscanceled(): 
#        print "DOWNLOAD CANCELLED" # need to get this part working
#        dp.close()
    if percent == 100:
        dp.close()

def getguide(TARGETFOLDER):
  custom_mac = xbmcaddon.Addon('script.XstreamingTV').getSetting("mac")
  MAIN_URL = 'http://cablecdn.com/XstreamingTV.php?mac='+custom_mac+'&file=guidevaderV2.xmltv.zip'
  downloadepath = TARGETFOLDER+'guide.zip'
  newfilepath = TARGETFOLDER+'sports.xml'
  currentfilepath = TARGETFOLDER+'guide.xmltv'
  dbnewfilepath = TARGETFOLDER+'sourcevaderback.db'
  dbcurrentfilepath = TARGETFOLDER+'source.db'
  dbpath = TARGETFOLDER+'source.db'

  iscompleted = DownloaderClass(MAIN_URL,downloadepath)
  if iscompleted == 'Done':
    try:
      zip_ref = zipfile.ZipFile(downloadepath, 'r')
      zip_ref.extractall(TARGETFOLDER)
      zip_ref.close()
      os.remove(downloadepath)
      unzipvalue = 'Done'
    except:
      unzipvalue = 'Failed'
    if unzipvalue == 'Done':
      if os.path.exists(currentfilepath):
#        if os.path.exists(dbpath):
#          os.remove(dbpath)
        os.remove(currentfilepath)
      os.rename(newfilepath, currentfilepath)
      if os.path.exists(dbcurrentfilepath):
#        if os.path.exists(dbpath):
#          os.remove(dbpath)
        os.remove(dbcurrentfilepath)
      os.rename(dbnewfilepath, dbcurrentfilepath)

def downloadlogos(TARGETFOLDER):
  custom_mac = xbmcaddon.Addon('script.XstreamingTV').getSetting("mac")
  MAIN_URL = 'http://cablecdn.com/XstreamingTV.php?mac='+custom_mac+'&file=logosVader.zip'
  downloadepath = TARGETFOLDER+'logos.zip'
  iscompleted = DownloaderClass(MAIN_URL,downloadepath)
  if iscompleted == 'Done':
    try:
      zip_ref = zipfile.ZipFile(downloadepath, 'r')
      zip_ref.extractall(TARGETFOLDER)
      zip_ref.close()
      unzipvalue = 'Done'
    except:
      unzipvalue = 'Failed'

def checklogos(TARGETFOLDER):
  if not os.path.exists(TARGETFOLDER+'logos/'):
    os.makedirs(TARGETFOLDER+'logos/')
    downloadlogos(TARGETFOLDER)

  if not os.path.exists(TARGETFOLDER+'logos/logobuild.txt'):
    downloadlogos(TARGETFOLDER)

  logobuildnumber = urllib2.urlopen("http://pythonwithphp.com/logosvader.txt").read()

  GetVersion = TARGETFOLDER+'logos/logobuild.txt'

  currentversion = open(GetVersion).read()

  if currentversion < logobuildnumber:
    downloadlogos(TARGETFOLDER)

custom_mac = xbmcaddon.Addon('script.XstreamingTV').getSetting("mac")

if custom_mac == '00:00:00:00:00:00':
  try:
    try:
      getethmac = open('/sys/class/net/eth0/address').read()
      custom_key1 = getethmac.replace(':','')
      custom_mac = custom_key1[:12]
    except:
      try:
        getethmac = open('/sys/class/net/wlan0/address').read()
        custom_key1 = getethmac.replace(':','')
        custom_mac = custom_key1[:12]
      except:
        from itertools import izip
        import uuid
        token = ""
        mac_address = "%012x" % uuid.getnode()
        iter_mac_address = iter(mac_address)
        custom_mac = "%s%s" % (token, token.join(a+b for a, b in izip(iter_mac_address, iter_mac_address)))
    __addonV2__ = xbmcaddon.Addon('script.XstreamingTV')
    __addonV2__.setSetting(id='mac', value=custom_mac)
  except:
    xbmc.executebuiltin('ActivateWindow(Home)')
    sys.exit(0)

custom_mac = xbmcaddon.Addon('script.XstreamingTV').getSetting("mac")

if custom_mac == '':
  xbmcgui.Dialog().ok('XstreamingTV', 'Device Address Failed')
  xbmc.executebuiltin('ActivateWindow(Home)')
  sys.exit(0)

try:
  req = requests.get(
    url='https://xstreamingtv.com/member/api/check-access/by-mac',
    params={
    '_key': 'zgkkbwMuHcgldXkMxfXM',
    'mac': custom_mac
    }
    )
  ret_json = req.json()
  status = ret_json['ok']
  if status:
    responsestatus = True
    statussubs = ret_json['status']
  else:
    responsestatus = False
    statussubs = '10'
except:
  responsestatus = False
  xbmc.executebuiltin('ActivateWindow(Home)')
#  xbmc.executebuiltin('RunAddon(script.XstreamingTV)')
  sys.exit(0)

if responsestatus == True:
  playerusername = xbmcaddon.Addon('plugin.video.XstreamingTV').getSetting("username")
  playerpassword = xbmcaddon.Addon('plugin.video.XstreamingTV').getSetting("password")
  if playerusername == '' or playerpassword == '':
    try:
      xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('XstreamingTV','Activating XstreamingTV', 200, ''))
      req = requests.get(
        url='https://xstreamingtv.com/member/api/check-access/by-mac',
        params={
        '_key': 'zgkkbwMuHcgldXkMxfXM',
        'mac': custom_mac
        }
        )
      ret_json = req.json()
      xtreamuser = ret_json['vader_username']
      xtreampass = ret_json['vader_password']
      __addon__ = xbmcaddon.Addon('plugin.video.XstreamingTV')
      __addon__.setSetting(id='username', value=xtreamuser)
      __addon__.setSetting(id='password', value=xtreampass)
      xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('XstreamingTV','XstreamingTV Activated', 200, ''))
    except:
      xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('XstreamingTV','Error When Activating. Please Retry', 200, ''))

if responsestatus == False:
  import orderit
  orderit.a()
elif statussubs == '0':
  import orderit
  orderit.c()
elif statussubs == '2':
  import orderit
  orderit.b()
elif responsestatus == True and statussubs == '1':
  try:
    statussubs = list(ret_json['categories'].values())[0]
  except:
    statussubs = 'Server unavailable.'
  xbmcgui.Dialog().ok('XstreamingTV', statussubs)