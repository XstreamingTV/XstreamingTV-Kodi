#   script.maintenancetool, Maintenance Tool
#   Copyright (C) 2015  Spencer Kuzara
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.



import urllib,urllib2,re, time
import xbmcgui,xbmcplugin
import os
import os
import xbmc
import xbmcaddon
import zipfile
import downloadg

time = 3000 #in miliseconds
__addon__ = xbmcaddon.Addon('script.XstreamingTV')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
loadingline = 'Loading'

thumbnailPath = xbmc.translatePath('special://thumbnails');
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'script.XstreamingTV')
mediaPath = os.path.join(addonPath, 'media')
databasePath = xbmc.translatePath('special://database')

#CLASSES

custom_mac = xbmcaddon.Addon('script.XstreamingTV').getSetting("mac")

if custom_mac == '00:00:00:00:00:00':
    try:
        try:
            getethmac = open('/sys/class/net/eth0/address').read()
            custom_key1 = getethmac.replace(':','')
            custom_mac = custom_key1[:12]
        except:
            try:
                getethmac = open('/sys/class/net/wlan0/address').read()
                custom_key1 = getethmac.replace(':','')
                custom_mac = custom_key1[:12]
            except:
                from itertools import izip
                import uuid
                token = ""
                mac_address = "%012x" % uuid.getnode()
                iter_mac_address = iter(mac_address)
                custom_mac = "%s%s" % (token, token.join(a+b for a, b in izip(iter_mac_address, iter_mac_address)))
        __addonV2__ = xbmcaddon.Addon('script.XstreamingTV')
        __addonV2__.setSetting(id='mac', value=custom_mac)
    except:
        xbmc.executebuiltin('ActivateWindow(Home)')
        sys.exit(0)

custom_mac = xbmcaddon.Addon('script.XstreamingTV').getSetting("mac")

if custom_mac == '':
    xbmcgui.Dialog().ok('XstreamingTV', 'Device Address Failed')
    xbmc.executebuiltin('ActivateWindow(Home)')
    sys.exit(0)

try:
    req = requests.get(
        url='https://xstreamingtv.com/member/api/check-access/by-mac',
        params={
        '_key': 'zgkkbwMuHcgldXkMxfXM',
        'mac': custom_mac
        }
        )
    ret_json = req.json()
    status = ret_json['ok']
    if status:
        responsestatus = True
        statussubs = ret_json['status']
        try:
            statussubsdate = list(ret_json['categories'].values())[0]
        except:
            statussubsdate = ''
    else:
        responsestatus = False
        statussubs = '10'
except:
    responsestatus = False
    statussubs = 'Invalid username'

newsubtext = ''

if responsestatus == False:
    newsubtext = '[COLOR darkgray]No subscription[/COLOR]'
else:
    if statussubs == '2':
        newsubtext = '[COLOR darkgray]'+'Subscription Expired'+'[/COLOR]'
    elif statussubs == '1':
        newsubtext = '[COLOR darkgray]'+statussubsdate+'[/COLOR]'
    elif statussubs == '0':
        newsubtext = '[COLOR darkgray]'+'Account activation pending'+'[/COLOR]'

if responsestatus == True:
    playerusername = xbmcaddon.Addon('plugin.video.XstreamingTV').getSetting("username")
    playerpassword = xbmcaddon.Addon('plugin.video.XstreamingTV').getSetting("password")
    if playerusername == '' or playerpassword == '':
        try:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('XstreamingTV','Activating XstreamingTV', 200, ''))
            req = requests.get(
                url='https://xstreamingtv.com/member/api/check-access/by-mac',
                params={
                '_key': 'zgkkbwMuHcgldXkMxfXM',
                'mac': custom_mac
                }
                )
            ret_json = req.json()
            xtreamuser = ret_json['vader_username']
            xtreampass = ret_json['vader_password']
            __addon__ = xbmcaddon.Addon('plugin.video.XstreamingTV')
            __addon__.setSetting(id='username', value=xtreamuser)
            __addon__.setSetting(id='password', value=xtreampass)
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('XstreamingTV','XstreamingTV Activated', 200, ''))
        except:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('XstreamingTV','Error When Activating. Please Retry', 200, ''))

if custom_mac == '':
    mactext = '[COLOR darkgray]Device Address Failed[/COLOR]'
else:
    mactext = '[COLOR darkgray]Device Address - '+custom_mac+'[/COLOR]'

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

def getmenumain(entries):
    entry = 'empty'
    dialog = xbmcgui.Dialog()
    nr = dialog.select("Select Menu", entries)
    if nr>=0:
        entry = entries[nr]
    else:
        sys.exit(0)
#       xbmc.executebuiltin('RunAddon(script.XstreamingTV)')

    return entry

def getmenu(entries):
    entry = 'empty'
    dialog = xbmcgui.Dialog()
    nr = dialog.select("Select Menu", entries)
    if nr>=0:
        entry = entries[nr]
    else:
        sys.exit(0)
#       xbmc.executebuiltin('RunAddon(script.XstreamingTV)')

    return entry

def scandirs(path):
    for root, dirs, files in os.walk(path):
        for currentFile in files:
            print "processing file: " + currentFile
            exts = ('.fi')
            if any(currentFile.lower().endswith(ext) for ext in exts):
                os.remove(os.path.join(root, currentFile))

def rundelete():
    try:
        fideletefolder = xbmc.translatePath(
            'special://home/temp'
            )

        scandirs(fideletefolder)
    except:
        pass

    try:
        fideletefolder = xbmc.translatePath(
            'special://home/temp/archive_cache'
            )

        scandirs(fideletefolder)
    except:
        pass

    try:
        fideletefolder = xbmc.translatePath(
            'special://home/cache'
            )

        scandirs(fideletefolder)
    except:
        pass

#DEFINE MENU

def mainMenu():
    addItem('TV Guide', 'url', 1,os.path.join(mediaPath, "TVGuideHomeFocus.png"))
    addItem('LIVE TV', 'url', 2,os.path.join(mediaPath, "LiveTVHomeFocus.png"))
    addItem('Sports', 'url', 3,os.path.join(mediaPath, "SportsHomeFocus.png"))
    addItem('VOD', 'url', 4,os.path.join(mediaPath, "VODHomeFocus.png"))
    addItem('Extra', 'url', 5,os.path.join(mediaPath, "ExtraHomeFocus.png"))
    addItem('Settings', 'url', 6,os.path.join(mediaPath, "SettingsDownFocus.png"))
    addItem('Status', 'url', 7,os.path.join(mediaPath, "StatusDownFocus.png"))
    addItem('Exit', 'url', 8,os.path.join(mediaPath, "ExitDownFocus.png"))
    
#ADD TO MENU

def TVGuide():
    __addon__ = xbmcaddon.Addon('script.XstreamingTVguide')
#   dialog = xbmcgui.Dialog()
#   entries = ["English Channels", "Spanish Channels", "All", "Sports", "Premium Movies", "United Kingdom", "United States"]
#   nr = dialog.select("Select Guide", entries)
    entry = 'empty'
#   if nr>=0:
#       entry = entries[nr]
#   else:
#       sys.exit(0)
    entry = 'English Channels'
    ChannelMode = 'Vaders'
    CategoryMode = 'All'
    if entry == 'English Channels':
        ChannelMode = 'Vaders'
    elif entry == 'Spanish Channels':
        ChannelMode = 'Vaders Spanish'
    elif entry == 'All':
        ChannelMode = 'All'
        CategoryMode = 'All'
    else:
        CategoryMode = entry

    if not entry == 'empty':
        __addon__.setSetting(id='ChannelMode', value=ChannelMode)
        __addon__.setSetting(id='CategoryMode', value=CategoryMode)
        xbmc.executebuiltin('RunAddon(script.XstreamingTVguide)')

def LIVETV():
    rundelete()
    entries = ["English Channels", "Spanish Channels","All Channels", "Country", "Search"]
    entry = getmenu(entries)
    if entry == 'English Channels':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XstreamingTV/livetv/category/all",return)')
    elif entry == 'All Channels':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XstreamingTV/livetv/category/International",return)')
    elif entry == 'Spanish Channels':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XstreamingTV/livetv/category/Spanish",return)')
    elif entry == 'Country':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XstreamingTV/livetv/category/alllllllll",return)')
    elif entry == 'Search':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XstreamingTV/livetv/category/Search",return)')

def Sports():
    rundelete()
    entries = ["Live Sports", "Match Center"]
    entry = getmenu(entries)
    if entry == 'Live Sports':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XstreamingTV/livetv/category/26",return)')
    elif entry == 'Match Center':
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('Match Center','Loading Please Wait', time2, __icon__))
        xbmc.executebuiltin('PlayMedia("plugin://plugin.video.XstreamingTV/mc/")')

def VOD():
    rundelete()
    entries = ["XstreamingTV VOD", "Internet VOD"]
    entry = getmenu(entries)
    if entry == 'XstreamingTV VOD':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XstreamingTV/vod/category/all/",return)')
    elif entry == 'Internet VOD':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.exodus/?action=HomeVOD",return)')

def Settings():
    rundelete()
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.XstreamingTV/tools")')

def Exit():
    os._exit(1)

def Extra():

    entries = ["Black & White Movies"]
    entry = getmenu(entries)
    if entry == '24/7 TV':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.247tv/?iconimage&amp;mode=Home&amp;name&amp;url",return)')
    elif entry == 'Black & White Movies':
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fncablebandw/?iconimage&amp;mode=Home&amp;name&amp;url",return)')

def Status():
    rundelete()
    entries = ["Manage Subscription", newsubtext, mactext]
    entry = getmenumain(entries)
    if entry == 'Manage Subscription':
        import downloadgmanage

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok


def addDir(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	
def addItem(name,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setArt({'fanart': __addon__.getAddonInfo('fanart')})
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

#PARSES CHOICE
      
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
							
	return param   

#WORK FUNCTIONS
def setupCacheEntries():
    entries = 5 #make sure this reflects the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries

#START MAIN           

params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
        mainMenu()

elif mode==1:
        TVGuide()

elif mode==2:
		LIVETV()
        
elif mode==3:
        Sports()

elif mode==4:
		VOD()

elif mode==5:
        Extra()

elif mode==6:
		Settings()

elif mode==7:
        Status()

elif mode==8:
        xbmc.executebuiltin('ActivateWindow(Home)')

xbmcplugin.endOfDirectory(int(sys.argv[1]))

