# -*- coding: utf-8 -*-
#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified for Mega Guide (09/2014 onwards)
#      by Thomas Geppert [bluezed] - bluezed.apps@gmail.com
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import xbmcaddon
import time
time = 2000 #in miliseconds
__addon__ = xbmcaddon.Addon('script.XstreamingTVguide')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
loadingline = 'Loading. Please Wait'

import gui

import os
import sys
import xbmcgui
import urllib2
import httplib
import urllib
import re
MegaFolder = xbmc.translatePath(
    'special://home/userdata/addon_data/script.managemegaguide/'
    )
import xml.etree.ElementTree as etree
#with open(MegaFolder+'settingsall.xml', 'r') as xml_file:
#    xml_tree = etree.parse(xml_file)
#import requests
import json

#tree = xml_tree
#root = tree.getroot()
#url = 'http://idragondev.com/GuideXMLFull/new.php'
#headers = {'Content-Type': 'application/json', 'Accept':'application/json'}

#	req = urllib2.Request(url, values, headers={ 'User-Agent': 'Mozilla/5.0' })

lst2 = []
d2 = {}

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

#for country in root.findall('setting'):
#    try:
#       settingelement = country.find("setting")
#		d2 = {}
#		findid = country.get('id')
#		foundvalue = country.get('value')
#		epg = country.get('epg')
#		print(epg)
#		if foundvalue == 'true':
#			d2['i']=findid
#			d2['e']=epg
#			lst2.append(d2)
#    except:
#        pass

#my_array3 = json.dumps(lst2)
#print(my_array3)
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]  
    return param
def checkingthem():
  import requests
  part_nums = ['ECA-1EHG102','CL05B103KB5NNNC','CC0402KRX5R8BB104']
  values = {'type': 'mac', 'value': custom_key}

  userdata = {"array": my_array3, "key": custom_key}
  #resp = requests.post(url, data = userdata)

  #headers = { 'User-Agent' : 'Mozilla/5.0' }
  #values = urllib.urlencode(userdata)
  #req = urllib2.Request(url, values)
  #html = urllib2.urlopen(req).read()
  #print (html)
  resp = requests.post(url, data = userdata)
  print (resp.text)

params=get_params(); url=None; name=None; mode=None; 
#mode = args.get('mode', None)

try: mode=int(params["mode"])
except: pass
if mode == None:
  xbmcgui.Dialog().ok(__addonname__, 'yes')
  checkingthem()